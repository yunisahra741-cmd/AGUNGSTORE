package id.agungstore.app;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private LinearLayout splash;

    private static final String HOME_URL =
            "https://agungofficial.biz.id/";

    private boolean firstPageLoaded = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        splash = findViewById(R.id.splash);

        // =========================
        // WEBVIEW SETTINGS
        // =========================

        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        // Cache
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // =========================
        // WEBVIEW
        // =========================

        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new StoreWebViewClient());

        // Splash hanya tampil saat pertama buka
        if (savedInstanceState == null) {

            splash.setVisibility(View.VISIBLE);
            webView.setVisibility(View.VISIBLE);

            webView.loadUrl(HOME_URL);

        } else {

            splash.setVisibility(View.GONE);

            webView.restoreState(savedInstanceState);

            firstPageLoaded = true;
        }

        // =========================
        // TOMBOL BACK
        // =========================

        getOnBackPressedDispatcher().addCallback(
                this,
                new OnBackPressedCallback(true) {

                    @Override
                    public void handleOnBackPressed() {

                        if (webView.canGoBack()) {

                            webView.goBack();

                        } else {

                            finish();

                        }

                    }

                }
        );

    }

    // =========================
    // WEBVIEW CLIENT
    // =========================

    private class StoreWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(
                WebView view,
                WebResourceRequest request
        ) {

            return handleUri(request.getUrl());

        }

        @Override
        public boolean shouldOverrideUrlLoading(
                WebView view,
                String url
        ) {

            return handleUri(Uri.parse(url));

        }

        private boolean handleUri(Uri uri) {

            String scheme = uri.getScheme();

            if (scheme == null) {
                return true;
            }

            // Link website tetap dibuka di aplikasi
            if (
                    "http".equalsIgnoreCase(scheme)
                            ||
                    "https".equalsIgnoreCase(scheme)
            ) {

                return false;

            }

            // Link aplikasi lain
            try {

                Intent intent =
                        new Intent(Intent.ACTION_VIEW, uri);

                startActivity(intent);

            } catch (ActivityNotFoundException e) {

                Toast.makeText(
                        MainActivity.this,
                        "Aplikasi untuk membuka tautan ini tidak tersedia",
                        Toast.LENGTH_SHORT
                ).show();

            }

            return true;

        }

        @Override
        public void onPageStarted(
                WebView view,
                String url,
                Bitmap favicon
        ) {

            /*
             * PENTING:
             * Jangan tampilkan splash lagi di sini.
             *
             * Sebelumnya splash muncul setiap klik game
             * karena setiap halaman baru memanggil onPageStarted().
             */

            super.onPageStarted(
                    view,
                    url,
                    favicon
            );

        }

        @Override
        public void onPageFinished(
                WebView view,
                String url
        ) {

            // Sembunyikan splash setelah halaman pertama selesai
            if (!firstPageLoaded) {

                splash.setVisibility(View.GONE);

                firstPageLoaded = true;

            }

            super.onPageFinished(
                    view,
                    url
            );

        }

        @Override
        public void onReceivedError(
                WebView view,
                WebResourceRequest request,
                WebResourceError error
        ) {

            if (request.isForMainFrame()) {

                if (!firstPageLoaded) {

                    splash.setVisibility(View.GONE);

                }

                Toast.makeText(
                        MainActivity.this,
                        "Gagal memuat halaman. Periksa koneksi internet.",
                        Toast.LENGTH_LONG
                ).show();

            }

            super.onReceivedError(
                    view,
                    request,
                    error
            );

        }

        @Override
        public void onReceivedHttpError(
                WebView view,
                WebResourceRequest request,
                WebResourceResponse errorResponse
        ) {

            if (
                    request.isForMainFrame()
                            &&
                    errorResponse.getStatusCode() >= 400
            ) {

                Toast.makeText(
                        MainActivity.this,
                        "Server mengembalikan error "
                                + errorResponse.getStatusCode(),
                        Toast.LENGTH_SHORT
                ).show();

            }

            super.onReceivedHttpError(
                    view,
                    request,
                    errorResponse
            );

        }

    }

    // =========================
    // SIMPAN STATE
    // =========================

    @Override
    protected void onSaveInstanceState(Bundle outState) {

        webView.saveState(outState);

        super.onSaveInstanceState(outState);

    }

    // =========================
    // DESTROY
    // =========================

    @Override
    protected void onDestroy() {

        if (webView != null) {

            webView.stopLoading();

            webView.loadUrl("about:blank");

            webView.clearHistory();

            webView.destroy();

        }

        super.onDestroy();

    }

}